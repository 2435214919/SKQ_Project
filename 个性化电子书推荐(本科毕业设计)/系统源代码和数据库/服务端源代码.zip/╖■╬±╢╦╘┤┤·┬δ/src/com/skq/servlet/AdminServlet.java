package com.skq.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class AdminServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        json = sb.toString();
        Gson gson = new Gson();
        User user = gson.fromJson(json, User.class);
        String uname = user.getUname();
        String pwd = user.getPwd();

        boolean u_check = true;
        u_check = checkusers(uname,pwd,u_check);
        if(u_check) {
            resp.getWriter().write("success");
        }else {
            resp.getWriter().write("failure");
        }

    }

	/*private boolean exit(String uname,String pwd,boolean b_exit) {
		DBHandler db_exit = new DBHandler();
		String sql_select = "select * from users where username=? and pwd=?";
		String a_exit = db_exit.query(sql_select, new String[] {uname,pwd});
		if(a_exit.isEmpty()) {
			b_exit = true;
			return b_exit;
		}else {
			b_exit = false;
			return b_exit;
		}
	}*/

    private boolean checkusers(String uname, String pwd, boolean b_check) {
        DBHandler db_check = new DBHandler();
        boolean b=db_check.checkUser("select * from admin where adminname=? and pwd=?",new String[]{uname,pwd});
        if(b){
            b_check = true;
            return b_check;
        }
        else {
            b_check = false;
            return b_check;
        }
    }

}
