package com.skq.servlet.collaborative;

import com.google.gson.Gson;
import com.skq.servlet.DBHandler;
import com.skq.servlet.Ev;
import com.skq.servlet.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RcmdServlet extends HttpServlet {

    private String uname;//目标用户名
    private String username;//临时用户名
    private String bid;
    private String strscore;
    //private int score;
    private List<Ev> evlist1 = new ArrayList<Ev>();//目标用户数据集，用来计算相似度。
    private List<Ev> evlist2 = new ArrayList<Ev>();//目标用户已评分数据集，用来计算相似度。
    private List<Ev> evlist3 = new ArrayList<Ev>();//目标用户未评分数据集，用来计算推荐度。
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();

        json = sb.toString();
        Gson gson = new Gson();
        User user = gson.fromJson(json, User.class);
        uname = user.getUname();
        //uname = "skq";
        ResultSet result1 = null;
        try {
            result1 = (ResultSet)SelectFromUser(uname);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        try {
            while (result1.next()){
                username = result1.getString(1);
                bid = result1.getString(2);
                strscore = result1.getString(3);
                Ev a =new Ev(username,bid,strscore);
                evlist1.add(a);
            }
        }catch (Exception e) {
        }

        List<String> list = new ArrayList<>();

        for (int i = 0;i < evlist1.size();i++){
            Ev ev = evlist1.get(i);
            String bid = ev.getBid();
            list.add(bid);
        }

        for (int i = 0; i < list.size(); i++) {
            ResultSet result2 = null;
            try {
                result2 = SelectFromBid(list.get(i),uname);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            while (true){
                try {
                    if (!result2.next()) break;
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    username = result2.getString(1);
                    bid = result2.getString(2);
                    strscore = result2.getString(3);
                    Ev a =new Ev(username,bid,strscore);
                    evlist2.add(a);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }




        List<String> namelist = new ArrayList<String>();
        for(int i = 0; i < evlist2.size(); i++){
            Ev ev = evlist2.get(i);
            if(!namelist.contains(ev.getUname())){
                namelist.add(ev.getUname());
            }
        }

        /*Gson gson = new Gson();
        String jsondata= gson.toJson(namelist);  //将json数组转换成字符串，供下面返回给android端使用
        resp.getWriter().write(jsondata);*/

        List<UserSim> simlist = new ArrayList<UserSim>();
        for(int i = 0; i < namelist.size(); i++){
            List<Integer> list1 = new ArrayList<>();//用来计算sim的第一组数据
            List<Integer> list2 = new ArrayList<>();//用来计算sim的第二组数据
            List<Ev> templist1 = new ArrayList<>();//存入计算后的sim数据
            String name = namelist.get(i);
            //添加templist1数据
            for(int j = 0;j<evlist2.size();j++){
                Ev ev = evlist2.get(j);
                if(name.equals(ev.getUname())){
                    templist1.add(ev);
                }

            }


            //
            for(int k = 0;k<evlist1.size();k++)//遍历目标用户
            {

                for(int l = 0;l<templist1.size();l++)//遍历第一个用户的临时表
                {

                    Ev ev1 = evlist1.get(k);
                    Ev ev2 = templist1.get(l);
                    if(ev1.getBid().equals(ev2.getBid())){
                        list1.add(Integer.valueOf(ev1.getScore()));
                        list2.add(Integer.valueOf(ev2.getScore()));
                    }
                }
            }
            //resp.getWriter().write(String.valueOf(list1));

            CalculateSim calculateSim = new CalculateSim();
            float em  = calculateSim.EMetric(list1,list2);
            float sim = calculateSim.Sim(em);
            UserSim us = new UserSim(name,sim);
            simlist.add(us);
        }

        /*Gson gson1 = new Gson();
        String jsondata1= gson1.toJson(simlist);
        resp.getWriter().write("用户推荐度"+jsondata1);*/


//到此事情终于有了转机。。。。。。。。。。。。。。。。。。。。。。。。。。。

        for(int i = 0;i < namelist.size();i++ ){
            ResultSet result4 = null;
            try {
                result4 = SelectFromUser(namelist.get(i));
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            //得到evlist3
            while (true){
                try {
                    if (!result4.next()) break;
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    username = result4.getString(1);
                    bid = result4.getString(2);
                    strscore = result4.getString(3);
                    Ev a =new Ev(username,bid,strscore);
                    evlist3.add(a);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }




        //遍历evlist3得到booklist
        List<String> booklist = new ArrayList<>();
        for(int i = 0; i < evlist3.size(); i++){
            Ev ev = evlist3.get(i);
            if(!booklist.contains(ev.getBid())){
                booklist.add(ev.getBid());
            }
        }

        booklist.removeAll(list);


        //计算出图书总分
        List<BookTotalScore> totalscorelist = new ArrayList<>();
        for(int i = 0; i < booklist.size(); i++){
            String bid = booklist.get(i);
            float score = 0;
            for(int j = 0; j < evlist3.size(); j++){
                Ev ev = evlist3.get(j);
                if(bid.equals(ev.getBid())){
                    for(int k = 0; k < simlist.size(); k++){
                        UserSim userSim = simlist.get(k);
                        if(ev.getUname().equals(userSim.getUsername())){
                            float uscore = Float.parseFloat(ev.getScore());
                            score = score + userSim.getSim()*uscore;
                        }
                    }
                }
            }
            BookTotalScore bookTotalScore = new BookTotalScore(bid,score);
            totalscorelist.add(bookTotalScore);
        }

        /*Gson gson2 = new Gson();
        String jsondata2= gson2.toJson(totalscorelist);
        resp.getWriter().write("图书总分" +jsondata2);*/



        //计算总相似性
        List<BookSim> booksimlist = new ArrayList<>();
        for(int i = 0; i < booklist.size(); i++){
            String bid = booklist.get(i);
            float sim = 0;
            for(int j = 0; j < evlist3.size(); j++){
                Ev ev = evlist3.get(j);
                if(bid.equals(ev.getBid())){
                    for(int k = 0; k < simlist.size(); k++){
                        UserSim userSim = simlist.get(k);
                        if(ev.getUname().equals(userSim.getUsername())){
                            sim = sim + userSim.getSim();
                        }
                    }
                }
            }
            BookSim bookSim = new BookSim(bid,sim);
            booksimlist.add(bookSim);
        }

        /*Gson gson3 = new Gson();
        String jsondata3= gson3.toJson(booksimlist);
        resp.getWriter().write("总相关性"+jsondata3);*/

        //计算推荐度
        List<BookReconmend> bookreconmendlist = new ArrayList<>();
        for(int i = 0; i < totalscorelist.size(); i++){
            BookTotalScore b = totalscorelist.get(i);
            String bid = b.getBid();
            float recpoint = 0;
            for (int j = 0; j<booksimlist.size(); j++){
                BookSim bookSim = booksimlist.get(j);
                if(bid==bookSim.getBid()){recpoint = b.getScore()/bookSim.getSim();}
            }
            BookReconmend bookReconmend = new BookReconmend(bid,recpoint);
            bookreconmendlist.add(bookReconmend);
        }

        List<BookRcInt> bookrcintlist = new ArrayList<>();
        for(int i = 0; i < totalscorelist.size(); i++){
            BookTotalScore b = totalscorelist.get(i);
            String bid = b.getBid();
            float recpoint = 0;
            for (int j = 0; j<booksimlist.size(); j++){
                BookSim bookSim = booksimlist.get(j);
                if(bid.equals(bookSim.getBid())){recpoint = 100000*((b.getScore()/bookSim.getSim()));}
            }
            BookRcInt bookRcInt = new BookRcInt(bid, (int) recpoint);
            bookrcintlist.add(bookRcInt);
        }


        /*Gson gson4 = new Gson();
        String jsondata4= gson4.toJson(bookreconmendlist);
        resp.getWriter().write("图书推荐度"+jsondata4);*/

        //将推荐表按照推荐度排序
        bookrcintlist.sort(new Comparator<BookRcInt>() {
            @Override
            public int compare(BookRcInt o1, BookRcInt o2) {
                if(o1.getRecpoint() == null||o2.getRecpoint() == null)
                    return 0;
                return o1.getRecpoint().compareTo(o2.getRecpoint());
            }
        });

        /*Gson gson4 = new Gson();
        String jsondata4= gson4.toJson(bookrcintlist);
        resp.getWriter().write("图书推荐度"+jsondata4);*/

        //依据排序后的推荐度查找
        JSONArray jsonArray = new JSONArray();
        for(int i = 0; i<bookrcintlist.size(); i++) {
            BookRcInt b = bookrcintlist.get(i);
            String bid = b.getBid();
            ResultSet result5 = null;
            try {
                result5 = SelectFromBidForBook(bid);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
                while (result5.next()) {
                    JSONObject jObject = new JSONObject();  //json临时对象
                    jObject.put("bname", result5.getString(1));
                    jObject.put("bauth", result5.getString(2));
                    jObject.put("bpress", result5.getString(3));
                    jObject.put("bcls", result5.getString(4));
                    jObject.put("bscore", result5.getString(5));
                    jObject.put("bcount", result5.getString(6));
                    jObject.put("bid", result5.getString(7));
                    jsonArray.add(jObject);   //将封装好的json对象放入json数组
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }




        /*Gson gson = new Gson();
        String jsondata = gson.toJson(jsonArray);*/

        String jsondata=jsonArray.toString();
        resp.getWriter().write(jsondata);

        //清空所有表
        evlist1.clear();
        evlist2.clear();
        evlist3.clear();
        namelist.clear();
        simlist.clear();
        booklist.clear();
        booksimlist.clear();
        totalscorelist.clear();
        bookreconmendlist.clear();
        jsonArray.clear();
        bookrcintlist.clear();

    }

    public ResultSet SelectFromUser(String username) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select username,b_id,u_score from u_b_score where username = ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {username});
        return result;
    }

    public ResultSet SelectFromBid(String bid,String username) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select username,b_id,u_score from u_b_score where b_id = ? and username != ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {bid,username});
        return result;
    }

    public ResultSet SelectFromBidForBook(String bid) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_id = ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {bid});
        return result;
    }

}
