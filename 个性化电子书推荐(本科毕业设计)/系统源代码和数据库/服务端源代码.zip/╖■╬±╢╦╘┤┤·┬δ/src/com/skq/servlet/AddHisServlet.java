package com.skq.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class AddHisServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        json = sb.toString();
        Gson gson = new Gson();
        Add add = gson.fromJson(json, Add.class);
        String uname = add.getUname();
        String bid = add.getBid();
        del(uname,bid);
        insert(uname,bid);

    }



    private void insert(String uname, String bid) {
        DBHandler db_insert = new DBHandler();
        String sql = "insert into user_history(username,b_id,date) values (?,?,now())";
        db_insert.insert(sql, new String[] {uname, bid});
    }

    private void del(String uname, String bid) {
        DBHandler db_insert = new DBHandler();
        String sql = "DELETE FROM user_history WHERE (username =? and b_id =?) ";
        db_insert.insert(sql, new String[] {uname, bid});
    }


}
