package com.skq.servlet;

public class Add {
    private String uname;

    private String bid;

    public String getUname() {
        return uname;
    }

    public String getBid() {
        return bid;
    }
}
