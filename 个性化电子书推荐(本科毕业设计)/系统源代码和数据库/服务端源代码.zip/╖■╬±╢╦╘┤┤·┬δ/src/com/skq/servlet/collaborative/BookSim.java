package com.skq.servlet.collaborative;

public class BookSim {

    private String bid;

    private float sim;

    public BookSim(String bid,float sim){

        this.bid = bid;

        this.sim = sim;
    }

    public String getBid() {
        return bid;
    }

    public float getSim() {
        return sim;
    }
}
