package com.skq.servlet.collaborative;

import com.skq.servlet.DBHandler;
import com.skq.servlet.Ev;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class rcmdtest {
    private String uname;//目标用户名
    private String username;//临时用户名
    private String bid;
    private String strscore;
    private int score;
    private List<Ev> evlist1 = new ArrayList<Ev>();//目标用户已评分数据集，用来计算相似度。
    private List<Ev> evlist2 = new ArrayList<Ev>();//目标用户未评分数据集，用来计算推荐度。
    private List<Ev> evlist3 = new ArrayList<Ev>();//目标用户未评分数据集,且除去目标用户已评价图书。

    public void rcmd() throws SQLException {
        //uname = "skq";
        ResultSet result1 = null;
        result1 = (ResultSet)SelectFromUser(uname);

        try {
            while (result1.next()){
                username = result1.getString(1);
                bid = result1.getString(2);
                strscore = result1.getString(3);
                Ev a =new Ev(username,bid,strscore);
                evlist1.add(a);
            }
        }catch (Exception e) {
        }

        List<String> list = null;
        for (int i = 0;i < evlist1.size();i++){
            Ev ev = evlist1.get(i);
            list.add(ev.getBid());
        }

        for (int i = 0; i < list.size(); i++) {
            ResultSet result2 = null;
            result2 = SelectFromBid(list.get(i),uname);
            while (result2.next()){
                username = result2.getString(1);
                bid = result2.getString(2);
                strscore = result2.getString(3);
                Ev a =new Ev(username,bid,strscore);
                evlist2.add(a);
            }
        }

        List<String> namelist = null;
        for(int i = 0; i < evlist2.size(); i++){
            Ev ev = evlist2.get(i);
            if(!namelist.contains(ev.getUname())){
                namelist.add(String.valueOf(ev.getUname()));
            }
        }
        
        List<UserSim> simlist = new ArrayList<UserSim>();//存入计算后的sim数据
        for(int i = 0; i < namelist.size(); i++){
            String username = namelist.get(i);
            List<Integer> list1 = null;//用来计算sim的第一组数据
            List<Integer> list2 = null;//用来计算sim的第二组数据
            List<Ev> templist1 = new ArrayList<Ev>();

            //添加templist1数据
            for(int j = 0;j<evlist2.size();j++){
                Ev ev = evlist2.get(j);
                if(username == ev.getUname()){ templist1.add(ev); }

            }

            //
            for(int k = 0;k<evlist1.size();k++)//遍历目标用户
            {

                for(int l = 0;l<templist1.size();l++)//遍历第一个用户的临时表
                {

                    Ev ev1 = evlist1.get(k);
                    Ev ev2 = templist1.get(l);
                    if(ev1.getUname() == ev2.getUname()){
                        list1.add(Integer.valueOf(ev1.getScore()));
                        list2.add(Integer.valueOf(ev2.getScore()));
                    }
                }
            }

            CalculateSim calculateSim = new CalculateSim();
            float em  = calculateSim.EMetric(list1,list2);
            float sim = calculateSim.Sim(em);
            UserSim us = new UserSim(username,sim);
            simlist.add(us);
        }

        for(int i = 0;i<namelist.size();i++){
            ResultSet result3 = SelectFromUser2(namelist.get(i));
            while (result3.next()){
                username = result3.getString(1);
                bid = result3.getString(2);
                strscore = result3.getString(3);
                Ev a =new Ev(username,bid,strscore);
                evlist3.add(a);
            }
        }


    }

    public ResultSet SelectFromUser(String username) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select * from u_b_score where username = ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {username});
        return result;
    }

    public ResultSet SelectFromBid(String bid,String username) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select * from u_b_score where b_id = ? and username != ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {bid,username});
        return result;
    }

    public ResultSet SelectFromUser2(String username) throws SQLException {
        DBHandler dbHandler =new DBHandler();
        String sql = "select * from u_b_score where username != ?";
        ResultSet result = (ResultSet) dbHandler.getSelect(sql,new String[] {username});
        return result;
    }

}
