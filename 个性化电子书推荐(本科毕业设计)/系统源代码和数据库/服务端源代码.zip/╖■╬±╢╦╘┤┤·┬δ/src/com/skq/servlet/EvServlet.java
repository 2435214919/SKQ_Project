package com.skq.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class EvServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();

        json = sb.toString();
        Gson gson = new Gson();
        Ev ev = gson.fromJson(json, Ev.class);
        float score = Float.parseFloat(ev.getScore());
        String bid = ev.getBid();
        String username = ev.getUname();
        in_ubcore(username,bid, String.valueOf(score));

        int count = count(bid);
        float sc = (score(bid)*count+score)/(count+1);//计算新分数；
        updata(sc,bid);
        NumberFormat formatter = new DecimalFormat("0.0");
        String str_sc = formatter.format(sc);
        resp.getWriter().write(String.valueOf(str_sc));

    }

    private void updata(float sc,String bid) {
        DBHandler db_upscore = new DBHandler();
        db_upscore.insert("UPDATE tb_book SET b_score=? WHERE b_id=?",new String[] {String.valueOf(sc),bid});
    }


    private float score(String bid) {
        DBHandler db_score = new DBHandler();
        String result = db_score.query("select b_score from tb_book where b_id=?", new String[] {bid});
        float score = Float.parseFloat(result);
        return score;
    }

    private int count(String bid) {
        DBHandler db_score = new DBHandler();
        String result = db_score.query("select b_count from tb_book where b_id=?", new String[] {bid});
        int count = Integer.parseInt(result);
        db_score.insert("UPDATE tb_book SET b_count=b_count+1 WHERE b_id=?", new String[] {bid});
        return count;
    }

    private void in_ubcore(String uname, String bid,String uscore) {
        DBHandler db_insert = new DBHandler();
        String sql = "insert into u_b_score(username,b_id,u_score) values (?,?,?)";
        db_insert.insert(sql, new String[] {uname, bid,uscore});
    }

}
