package com.skq.servlet;

import java.io.Serializable;

public class UserValue implements Serializable {
    private String uname;
    private String lit,life,popsci,math,hlth,emo,grow,edu,trav,msc,art,camer;


    public UserValue(String uname,String lit,String life,String popsci,String math,String hlth,String emo,String grow,
                 String edu,String trav,String msc,String art,String camer){
        this.uname = uname;
        this. lit= lit;
        this. life= life;
        this. popsci= popsci;
        this. math= math;
        this. hlth= hlth;
        this. emo= emo;
        this. grow= grow;
        this. edu= edu;
        this. trav= trav;
        this. msc= msc;
        this. art= art;
        this. camer= camer;
    }

    public String getName(){
        return uname;
    }
    public String getLit(){
        return lit;
    }
    public String getLife(){
        return life;
    }
    public String getPopsci(){
        return popsci;
    }
    public String getMath(){
        return math;
    }
    public String getHlth(){ return hlth; }
    public String getEmo(){
        return emo;
    }
    public String getGrow(){
        return grow;
    }
    public String getEdu(){
        return edu;
    }
    public String getTrav(){ return trav; }
    public String getMsc(){
        return msc;
    }
    public String getArt(){
        return art;
    }
    public String getCamer(){
        return camer;
    }

}
