package com.skq.servlet;

import java.sql.*;

import com.mysql.jdbc.Statement;

public class DatabaseUtil {

//	private static Connection mConnection;

	/*private static Connection getConnection() {
		if (mConnection == null) {
			String url = "jdbc:mysql://106.12.42.105:3306/myappdb";
			try {
				Class.forName("com.mysql.jdbc.Driver");
				mConnection = (Connection) DriverManager.getConnection(url, "admin", "123456");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return mConnection;
	}
*/
	private static Connection conn;
	public static Connection getConn(){
		String url = "jdbc:mysql://106.12.42.105:3306/myappdb";
		String user="admin";
		String pwd="123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, pwd);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return conn;
	}

	public static ResultSet query(String querySql) throws SQLException {
		Statement stateMent = (Statement) getConn().createStatement();
		return stateMent.executeQuery(querySql);
	}
	
	public static void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
				conn = null;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
