package com.skq.servlet;

import com.google.gson.Gson;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class test extends HttpServlet {
    private int lit, life, popsci, math, hlth, emo, grow, edu, trav, msc, art, camer;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader(req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");

        String temp;
        while((temp = br.readLine()) != null) {
            sb.append(temp);
        }

        br.close();
        String json = sb.toString();
        Gson gson = new Gson();
        JSONArray jsonArray = new JSONArray();
        ResultSet result1 = null;

        try {
            result1 = (ResultSet)this.select();
        } catch (SQLException var15) {
            var15.printStackTrace();
        }

        try {
            while(result1.next()) {
                JSONObject jObject = new JSONObject();
                jObject.put("bname", result1.getString(1));
                jObject.put("bauth", result1.getString(2));
                jObject.put("bpress", result1.getString(3));
                jObject.put("bcls", result1.getString(4));
                jObject.put("bscore", result1.getString(5));
                jObject.put("bcount", result1.getString(6));
                jObject.put("bid", result1.getString(7));
                jsonArray.add(jObject);
            }
        } catch (SQLException var16) {
            var16.printStackTrace();
        }

        String jsondata = jsonArray.toString();
        resp.getWriter().write(jsondata);
    }

    private Object select() throws SQLException {
        DBHandler db_result = new DBHandler();

        ResultSet result = (ResultSet) db_result.getSelect2("(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)order by b_count DESC"
                , new String[]{"math","2","art","2","lit","2"});
        return result;


    }
}
