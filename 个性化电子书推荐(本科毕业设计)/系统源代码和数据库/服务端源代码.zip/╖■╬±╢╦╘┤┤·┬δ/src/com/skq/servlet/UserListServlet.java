package com.skq.servlet;

import com.google.gson.Gson;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserListServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader(req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        JSONArray jsonArray=new JSONArray();

        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }

        br.close();
        String json = sb.toString();
        Gson gson = new Gson();
        User user = gson.fromJson(json, User.class);
        String username = user.getUname();
        ResultSet result = null;
        try {
            while (result.next()) {
                JSONObject jObject=new JSONObject();  //json临时对象
                jObject.put("listname", result.getString(1));
                jsonArray.add(jObject);   //将封装好的json对象放入json数组
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        String jsondata=jsonArray.toString();  //将json数组转换成字符串，供下面返回给android端使用
        //System.out.println(jsondata);  //本地测试用
        resp.getWriter().write(jsondata);


    }

    private Object searchlist(String uname) throws SQLException {
        DBHandler db_result = new DBHandler();
        String sql = "select list_name from user_list where username = ?";
        ResultSet result = (ResultSet) db_result.getSelect(sql,new  String[]{uname});
        return result;
    }



}
