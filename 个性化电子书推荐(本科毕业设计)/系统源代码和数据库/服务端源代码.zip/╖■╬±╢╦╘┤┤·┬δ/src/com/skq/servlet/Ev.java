package com.skq.servlet;

import java.io.Serializable;

public class Ev{

    private String uname;

    private String bid;

    private String score;

    public Ev(String uname,String bid,String score){
        this.uname = uname;
        this.bid = bid;
        this.score = score;
    }

    public String getUname(){
        return uname;
    }
    public String getBid() {
        return bid;
    }
    public String getScore() {
        return score;
    }



}
