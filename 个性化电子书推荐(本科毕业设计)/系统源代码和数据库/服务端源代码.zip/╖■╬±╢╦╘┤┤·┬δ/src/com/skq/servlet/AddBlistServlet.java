package com.skq.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class AddBlistServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader(req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");

        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }

        br.close();
        String json = sb.toString();
        Gson gson = new Gson();
        BlistUser blistUser = gson.fromJson(json, BlistUser.class);
        String uname = blistUser.getUname();
        String listname = blistUser.getListname();
        insert(uname,listname);
        resp.getWriter().write("true");

    }

    private void insert(String uname,String listname) {
        DBHandler db_insert = new DBHandler();
        String sql = "insert into user_list(username,list_name) values (?,?)";
        db_insert.insert(sql, new String[] {uname,listname});
    }
}
