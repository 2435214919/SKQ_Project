package com.skq.servlet.collaborative;

import java.io.Serializable;

public class UserSim implements Serializable {
    private String username;

    private float sim;

    public UserSim(String username,float sim){
        this.username = username;
        this.sim = sim;
    }

    public String getUsername() {
        return username;
    }

    public float getSim(){
        return sim;
    }

}
