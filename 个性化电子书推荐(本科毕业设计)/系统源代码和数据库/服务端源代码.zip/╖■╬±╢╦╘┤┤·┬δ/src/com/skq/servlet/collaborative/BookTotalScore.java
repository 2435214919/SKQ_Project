package com.skq.servlet.collaborative;

public class BookTotalScore {

    private String bid;

    private float score;

    public BookTotalScore(String bid,float score){

        this.bid = bid;

        this.score = score;
    }

    public String getBid() {
        return bid;
    }

    public float getScore() {
        return score;
    }
}
