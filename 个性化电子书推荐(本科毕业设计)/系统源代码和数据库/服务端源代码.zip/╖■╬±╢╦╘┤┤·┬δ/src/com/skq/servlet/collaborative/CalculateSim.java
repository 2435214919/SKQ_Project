package com.skq.servlet.collaborative;

import java.util.List;

public class CalculateSim {

    //计算欧式距离
    public float EMetric(List<Integer> listx, List<Integer> listy){
        float em = 0;
        for(int i = 0;i < listx.size();i++){
            float diff = listx.get(i) - listy.get(i);
            em = em + diff * diff;
        }
        em = (float) Math.sqrt(em);
        return em;
    }

    //计算相似度
    public float Sim(float em){
        float sim = 1/(1+em);
        return sim;
    }
}
