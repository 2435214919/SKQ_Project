package com.skq.servlet;

import java.io.Serializable;

public class Book implements Serializable {
    private String name;
    private String auth;
    private String press;
    private String cls;
    private String id;

    public Book(String name,String auth,String press,String cls,String id){
        this.name = name;
        this.auth = auth;
        this.press = press;
        this.cls = cls;
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public String getAuth(){
        return auth;
    }

    public String getPress(){
        return press;
    }

    public String getCls(){
        return cls;
    }

    public String getId(){
        return id;
    }

}
