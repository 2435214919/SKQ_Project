package com.skq.servlet;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler {
	String url = "jdbc:mysql://106.12.42.105:3306/myappdb";
	String user="shenkunqi";
	String pwd="Skq123456!";
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	private Object ResultSet;

	public Connection getConn(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, pwd);
		}catch(Exception ex){
			ex.printStackTrace();
		}		
		return conn;
	}

	public String query(String sql,String[] args){
		String result="";
		try{
			conn=getConn();
			System.out.println(sql);
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++){
				ps.setString(i+1, args[i]);
			}			
			rs=ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();			
			int count=rsmd.getColumnCount();
			System.out.println(count);
			while (rs.next()) {
				for(int i=1;i<=count;i++){
					//result+=rs.getString(i)+"*";
					result+=rs.getString(i);
				}				
			}
		}catch (Exception ex) {
			ex.printStackTrace();
		}		
		return result;		
	}

	public boolean insert(String sql,String[] args){
		boolean flag=false;
		try{
			conn=getConn();
			System.out.println(sql);
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++){
				ps.setString(i+1, args[i]);
			}			
			int i=ps.executeUpdate();
			System.out.println(i);
			if(i==1){
				flag=true;
			}
		}catch (Exception ex) {
			ex.printStackTrace();
		}		
		return flag;
	}

	public boolean checkUser(String sql,String[] args){
		boolean flag=false;
		try{
			conn=getConn();
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++){
				ps.setString(i+1, args[i]);
			}			
			rs=ps.executeQuery();
			if(rs.next()){
				flag=true;
			}
		}catch (Exception ex) {
			ex.printStackTrace();
		}		
		return flag;
	}

	public Object getSelect(String sql) throws SQLException {
		List<String> list = new ArrayList<String>();
		conn=getConn();
		ps=conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		return rs;

		/*try {
			conn=getConn();
			ps=conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			*//*while (rs.next()) {
				// 将查询出的内容添加到list中，其中userName为数据库中的字段名称
				list.add(rs.getString("bname"));
				list.add(rs.getString("bauth"));
				list.add(rs.getString("bpress"));
			}*//*
		} catch (Exception e) {
		}*/

	}

	public static void main(String[] args){
		DBHandler dbh=new DBHandler();
		String result=dbh.query(
				"select * from users where username=? and pwd=?",
				new String[] { "skq", "123" });
		System.out.println(result);
	}

	public Object getSelect(String sql,String[] args) throws SQLException {
		List<String> list = new ArrayList<String>();

		try{
			conn=getConn();
			System.out.println(sql);
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i++){
				ps.setString(i+1, args[i]);
			}
			rs=ps.executeQuery();

		}catch (Exception ex) {
			ex.printStackTrace();
		}
		return rs;
	}

	public Object getSelect2(String sql,String[] args) throws SQLException {

		try{
			conn=getConn();
			System.out.println(sql);
			ps=conn.prepareStatement(sql);
			for(int i=0;i<args.length;i=i+2 ){
				ps.setString(i+1, args[i]);
				ps.setInt(i+2, Integer.parseInt(args[i+1]));
			}
			rs=ps.executeQuery();

		}catch (Exception ex) {
			ex.printStackTrace();
		}
		return rs;
	}

	public boolean insertvalue(String sql,String[] args){
		boolean flag=false;
		try{
			conn=getConn();
			System.out.println(sql);
			ps=conn.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(args[0]));
			ps.setString(2, args[1]);
			int i=ps.executeUpdate();
			System.out.println(i);
			if(i==1){
				flag=true;
			}
		}catch (Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	

}
