package com.skq.servlet.collaborative;

public class BookReconmend {
    private String bid;

    private float recpoint;

    public BookReconmend(String bid,float recpoint){

        this.bid = bid;

        this.recpoint = recpoint;
    }

    public String getBid() {
        return bid;
    }

    public float getRecpoint() {
        return recpoint;
    }
}
