package com.skq.servlet;

import java.io.Serializable;

public class AddValue implements Serializable {

    private String uname;

    private String value;

    private String cls;

    public String getUname() {
        return uname;
    }

    public String getValue() {
        return value;
    }

    public String getCls(){return cls;}
}
