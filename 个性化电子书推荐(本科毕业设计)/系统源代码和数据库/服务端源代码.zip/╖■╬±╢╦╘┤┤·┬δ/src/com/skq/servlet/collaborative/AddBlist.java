package com.skq.servlet.collaborative;

import javax.servlet.http.HttpServlet;

public class AddBlist extends HttpServlet {

}
