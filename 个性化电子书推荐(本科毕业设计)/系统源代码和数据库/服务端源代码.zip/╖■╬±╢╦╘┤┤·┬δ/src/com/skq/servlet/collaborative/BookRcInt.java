package com.skq.servlet.collaborative;

public class BookRcInt {
    private String bid;

    private Integer recpoint;

    public BookRcInt(String bid,int recpoint){

        this.bid = bid;

        this.recpoint = recpoint;
    }

    public String getBid() {
        return bid;
    }

    public Integer getRecpoint() {
        return recpoint;
    }
}
