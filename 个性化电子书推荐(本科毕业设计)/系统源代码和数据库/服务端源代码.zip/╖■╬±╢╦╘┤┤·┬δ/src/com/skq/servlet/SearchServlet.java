package com.skq.servlet;

import com.google.gson.Gson;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SearchServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        json = sb.toString();
        Gson gson = new Gson();
        Add add = gson.fromJson(json, Add.class);
        String find = add.getBid();
        String str = "%" + find + "%";

        JSONArray jsonArray=new JSONArray(); //json数组

        ResultSet result1 = null;
        try {
            result1 = (ResultSet)select(str,result1);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        try {
//            ResultSet result = DatabaseUtil.query(sql);
            while (result1.next()) {
                JSONObject jObject=new JSONObject();  //json临时对象
                jObject.put("bname", result1.getString(1));
                jObject.put("bauth", result1.getString(2));
                jObject.put("bpress", result1.getString(3));
                jObject.put("bcls", result1.getString(4));
                jObject.put("bscore", result1.getString(5));
                jObject.put("bcount", result1.getString(6));
                jObject.put("bid", result1.getString(7));
                jsonArray.add(jObject);   //将封装好的json对象放入json数组
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        String jsondata=jsonArray.toString();  //将json数组转换成字符串，供下面返回给android端使用
        //System.out.println(jsondata);  //本地测试用
        resp.getWriter().write(jsondata);


    }

    private Object select() throws SQLException {
        DBHandler db_result = new DBHandler();
        ResultSet result = (ResultSet) db_result.getSelect("select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book " +
                "WHERE b_score BETWEEN 9.8 AND 10 order by b_score DESC");
        return result;
    }
    private Object select(String str1,ResultSet result1) throws SQLException {
        DBHandler db_result = new DBHandler();
        ResultSet result = (ResultSet) db_result.getSelect("(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id" +
                " from tb_book where (b_name like ?) or (b_press like ?) or (b_auth like ?) limit 30)" +
                "order by b_score DESC", new String[]{str1,str1,str1});
        return result;
    }

}
