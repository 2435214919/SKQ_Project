package com.skq.servlet;

public class UserInf {

    private String uname;

    private String sex;

    private String age;

    private String tag;

    public String getUname() {
        return uname;
    }

    public String getSex() {
        return sex;
    }

    public String getAge() {
        return age;
    }

    public String getTag() {
        return tag;
    }
}
