package com.skq.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class AddValueServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream)req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp,json;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        json = sb.toString();
        Gson gson = new Gson();
        AddValue add = gson.fromJson(json, AddValue.class);
        String uname = add.getUname();
        String value = add.getValue();
        String cls = add.getCls();
        /*String uname = "user01";
        String value = "1";
        String cls = "lit";*/
        insert(uname,value,cls);
        //resp.getWriter().write("success");
    }



    private void insert(String uname, String value,String cls) {
        DBHandler db_insert = new DBHandler();
        String sql ;
        switch (cls){
            case "lit":
                sql = "UPDATE user_value SET lit = lit + ? WHERE username = ?";
                break;
            case "life":
                sql = "UPDATE user_value SET life = life + ? WHERE username = ?";
                break;
            case "popsci":
                sql = "UPDATE user_value SET popsci = popsci + ? WHERE username = ?";
                break;
            case "math":
                sql = "UPDATE user_value SET math = math + ? WHERE username = ?";
                break;
            case "hlth":
                sql = "UPDATE user_value SET hlth = hlth + ? WHERE username = ?";
                break;
            case "emo":
                sql = "UPDATE user_value SET emo = emo + ? WHERE username = ?";
                break;
            case "grow":
                sql = "UPDATE user_value SET grow = grow + ? WHERE username = ?";
                break;
            case "edu":
                sql = "UPDATE user_value SET edu = edu + ? WHERE username = ?";
                break;
            case "trav":
                sql = "UPDATE user_value SET trav = trav + ? WHERE username = ?";
                break;
            case "msc":
                sql = "UPDATE user_value SET msc = msc + ? WHERE username = ?";
                break;
            case "art":
                sql = "UPDATE user_value SET art = art + ? WHERE username = ?";
                break;
            case "camer":
                sql = "UPDATE user_value SET camer = camer + ? WHERE username = ?";
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + cls);
        }

        db_insert.insertvalue(sql, new String[] {value,uname});
    }

}
