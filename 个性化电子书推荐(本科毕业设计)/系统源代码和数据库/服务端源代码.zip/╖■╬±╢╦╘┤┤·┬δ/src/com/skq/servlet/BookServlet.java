package com.skq.servlet;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class BookServlet extends HttpServlet {
    private int lit, life, popsci, math, hlth, emo, grow, edu, trav, msc, art, camer;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        super.service(req, resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");
        resp.addIntHeader("ycy", 101);
        PrintWriter out = resp.getWriter();
        System.out.println(req.getRequestURI());
        BufferedReader br = new BufferedReader(new InputStreamReader(req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");

        String temp;
        while((temp = br.readLine()) != null) {
            sb.append(temp);
        }

        br.close();
        String json = sb.toString();
        Gson gson = new Gson();
        Add add = (Add)gson.fromJson(json, Add.class);
        String uname = add.getUname();
        //String uname = "user01";
        JSONArray jsonArray1 = new JSONArray();
        JSONArray jsonArray2 = new JSONArray();
        ResultSet result1 = null;
        Map<String, String> paramsMap = null;

        try {
            result1 = (ResultSet)this.getvalue(uname);
        } catch (SQLException var15) {
            var15.printStackTrace();
        }
        paramsMap = new HashMap<String, String>();

        try {
            while(result1.next()) {
                JSONObject jObject = new JSONObject();
                jObject.put("uname", result1.getString(1));
                jObject.put("lit", result1.getString(2));
                jObject.put("life", result1.getString(3));
                jObject.put("popsci", result1.getString(4));
                jObject.put("math", result1.getString(5));
                jObject.put("hlth", result1.getString(6));
                jObject.put("emo", result1.getString(7));
                jObject.put("grow", result1.getString(8));
                jObject.put("edu", result1.getString(9));
                jObject.put("trav", result1.getString(10));
                jObject.put("msc", result1.getString(11));
                jObject.put("art", result1.getString(12));
                jObject.put("camer", result1.getString(13));
                jsonArray1.add(jObject);

            }
        } catch (SQLException var16) {
            var16.printStackTrace();
        }
        JSONObject jsonObject=jsonArray1.getJSONObject(0);
        String name=jsonObject.getString("uname");
        lit = Integer.parseInt(jsonObject.getString("lit"));
        life = Integer.parseInt(jsonObject.getString("life"));
        popsci = Integer.parseInt(jsonObject.getString("popsci"));
        math = Integer.parseInt(jsonObject.getString("math"));
        hlth = Integer.parseInt(jsonObject.getString("hlth"));
        emo = Integer.parseInt(jsonObject.getString("emo"));
        grow = Integer.parseInt(jsonObject.getString("grow"));
        edu = Integer.parseInt(jsonObject.getString("edu"));
        trav = Integer.parseInt(jsonObject.getString("trav"));
        msc = Integer.parseInt(jsonObject.getString("msc"));
        art = Integer.parseInt(jsonObject.getString("art"));
        camer = Integer.parseInt(jsonObject.getString("camer"));
        int sum = lit + life + popsci + math +
                hlth + emo + grow + edu + trav + msc + art + camer;

        String clit = String.valueOf(getcount(lit,sum));
        String clife = String.valueOf(getcount(life,sum));
        String cpopsci = String.valueOf(getcount(popsci,sum));
        String cmath = String.valueOf(getcount(math,sum));
        String chlth = String.valueOf(getcount(hlth,sum));
        String cemo = String.valueOf(getcount(emo,sum));
        String cgrow = String.valueOf(getcount(grow,sum));
        String cedu = String.valueOf(getcount(edu,sum));
        String ctrav = String.valueOf(getcount(trav,sum));
        String cmsc = String.valueOf(getcount(msc,sum));
        String cart = String.valueOf(getcount(art,sum));
        String ccamer = String.valueOf(getcount(camer,sum));

        ResultSet result = null;
        try {
            result = (ResultSet)select("lit",clit,
                    "life",clife,"popsci",cpopsci,"math",cmath,"hlth",chlth,"emo",cemo,
                    "grow",cgrow,"edu",cedu,"trav",ctrav,"msc",cmsc,"art",cart,
                    "camer",ccamer,result1);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        try {
            while (result.next()) {
                JSONObject jObject=new JSONObject();  //json临时对象
                jObject.put("bname", result.getString(1));
                jObject.put("bauth", result.getString(2));
                jObject.put("bpress", result.getString(3));
                jObject.put("bcls", result.getString(4));
                jObject.put("bscore", result.getString(5));
                jObject.put("bcount", result.getString(6));
                jObject.put("bid", result.getString(7));
                jsonArray2.add(jObject);   //将封装好的json对象放入json数组
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String jsondata=jsonArray2.toString();  //将json数组转换成字符串，供下面返回给android端使用
        //System.out.println(jsondata);  //本地测试用
        resp.getWriter().write(jsondata);


    }

    private Object getvalue(String str1) throws SQLException {
        DBHandler db_result = new DBHandler();
        Object result =  db_result.getSelect("select * from user_value where username = ?",new  String[] {str1});
        return result;
    }

    private int getcount(int value,int sum){
        int count = (100*value)/sum;
        return count;
    }

    private Object select(String str1,String str2,String str3,
                          String str4,String str5,String str6,
                          String str7,String str8,String str9,
                          String str10,String str11,String str12,
                          String str13,String str14,String str15,
                          String str16,String str17,String str18,
                          String str19,String str20,String str21,
                          String str22,String str23,String str24,
                          ResultSet result1) throws SQLException {
        DBHandler db_result = new DBHandler();

        ResultSet result = (ResultSet) db_result.getSelect2("(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)\n" +
                        "UNION all\n" +
                        "(select b_name,b_auth,b_press,b_cls,b_score,b_count,b_id from tb_book where b_cls=? limit ?)order by b_score DESC ,b_count DESC"
                , new String[]{str1,str2,str3,str4,str5,str6,str7,str8,str9,str10,str11,str12,
                        str13,str14,str15,str16,str17,str18,str19,str20,str21,str22,str23,str24});
        return result;
    }


}
