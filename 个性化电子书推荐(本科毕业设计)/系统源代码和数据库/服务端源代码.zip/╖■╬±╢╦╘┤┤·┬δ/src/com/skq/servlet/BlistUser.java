package com.skq.servlet;

public class BlistUser {
    private String listname;

    private String uname;

    public BlistUser(String listname,String username){
        this.listname = listname;
        this.uname = uname;
    }

    public String getListname(){
        return listname;
    }
    public String getUname() { return uname; }
}
