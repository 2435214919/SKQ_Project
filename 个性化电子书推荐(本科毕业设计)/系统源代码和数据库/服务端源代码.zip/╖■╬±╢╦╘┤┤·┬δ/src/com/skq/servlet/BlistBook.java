package com.skq.servlet;

public class BlistBook {
    private String listname;

    private String bid;

    public BlistBook(String listname,String bid){
        this.listname = listname;
        this.bid = bid;
    }

    public String getListname(){
        return listname;
    }
    public String getBid() {
        return bid;
    }


}
